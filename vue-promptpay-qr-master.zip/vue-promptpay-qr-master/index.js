import PromptpayQr from './src/components/PromptpayQr.vue'

PromptpayQr.install = function (Vue) {
  Vue.component('promptpay-qr', PromptpayQr)
}

export default PromptpayQr
